"""Generate test data for candlestick pattern unit tests from NASDAQ CSV files.

Scans CSV files with daily OHLC prices, runs each TA-Lib candlestick pattern
on sliding windows, and writes out Python test data files containing windows
where the pattern matched.

Usage:
    python -m py.candlestick_patterns.test_data_preparation.nyse.generate_test_data

Requirements:
    pip install ta-lib numpy
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import talib

# Window size matching _MIN_HISTORY in candlestick_patterns.py.
WINDOW_SIZE = 20

# Maximum number of test cases per pattern (to keep files manageable).
MAX_CASES_PER_PATTERN = 160

# Mapping: our pattern name -> TA-Lib function name.
PATTERN_MAP: dict[str, str] = {
    'abandoned_baby':                       'CDLABANDONEDBABY',
    'advance_block':                        'CDLADVANCEBLOCK',
    'belt_hold':                            'CDLBELTHOLD',
    'breakaway':                            'CDLBREAKAWAY',
    'closing_marubozu':                     'CDLCLOSINGMARUBOZU',
    'concealing_baby_swallow':              'CDLCONCEALBABYSWALL',
    'counterattack':                        'CDLCOUNTERATTACK',
    'dark_cloud_cover':                     'CDLDARKCLOUDCOVER',
    'doji':                                 'CDLDOJI',
    'doji_star':                            'CDLDOJISTAR',
    'dragonfly_doji':                       'CDLDRAGONFLYDOJI',
    'engulfing':                            'CDLENGULFING',
    'evening_doji_star':                    'CDLEVENINGDOJISTAR',
    'evening_star':                         'CDLEVENINGSTAR',
    'gravestone_doji':                      'CDLGRAVESTONEDOJI',
    'hammer':                               'CDLHAMMER',
    'hanging_man':                          'CDLHANGINGMAN',
    'harami':                               'CDLHARAMI',
    'harami_cross':                         'CDLHARAMICROSS',
    'high_wave':                            'CDLHIGHWAVE',
    'hikkake':                              'CDLHIKKAKE',
    'hikkake_modified':                     'CDLHIKKAKEMOD',
    'homing_pigeon':                        'CDLHOMINGPIGEON',
    'identical_three_crows':                'CDLIDENTICAL3CROWS',
    'in_neck':                              'CDLINNECK',
    'inverted_hammer':                      'CDLINVERTEDHAMMER',
    'kicking':                              'CDLKICKING',
    'kicking_by_length':                    'CDLKICKINGBYLENGTH',
    'ladder_bottom':                        'CDLLADDERBOTTOM',
    'long_legged_doji':                     'CDLLONGLEGGEDDOJI',
    'long_line':                            'CDLLONGLINE',
    'marubozu':                             'CDLMARUBOZU',
    'matching_low':                         'CDLMATCHINGLOW',
    'mat_hold':                             'CDLMATHOLD',
    'morning_doji_star':                    'CDLMORNINGDOJISTAR',
    'morning_star':                         'CDLMORNINGSTAR',
    'on_neck':                              'CDLONNECK',
    'piercing':                             'CDLPIERCING',
    'rickshaw_man':                         'CDLRICKSHAWMAN',
    'rising_falling_three_methods':         'CDLRISEFALL3METHODS',
    'separating_lines':                     'CDLSEPARATINGLINES',
    'shooting_star':                        'CDLSHOOTINGSTAR',
    'short_line':                           'CDLSHORTLINE',
    'spinning_top':                         'CDLSPINNINGTOP',
    'stalled':                              'CDLSTALLEDPATTERN',
    'stick_sandwich':                       'CDLSTICKSANDWICH',
    'takuri':                               'CDLTAKURI',
    'tasuki_gap':                           'CDLTASUKIGAP',
    'three_black_crows':                    'CDL3BLACKCROWS',
    'three_inside':                         'CDL3INSIDE',
    'three_line_strike':                    'CDL3LINESTRIKE',
    'three_outside':                        'CDL3OUTSIDE',
    'three_stars_in_the_south':             'CDL3STARSINSOUTH',
    'three_white_soldiers':                 'CDL3WHITESOLDIERS',
    'thrusting':                            'CDLTHRUSTING',
    'tristar':                              'CDLTRISTAR',
    'two_crows':                            'CDL2CROWS',
    'unique_three_river':                   'CDLUNIQUE3RIVER',
    'up_down_gap_side_by_side_white_lines': 'CDLGAPSIDESIDEWHITE',
    'upside_gap_two_crows':                 'CDLUPSIDEGAP2CROWS',
    'x_side_gap_three_methods':             'CDLXSIDEGAP3METHODS',
}


def parse_csv(path: Path) -> tuple[str, list[str], np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Parse a NYSE CSV file, returning mnemonic, dates and OHLC arrays (already chronological)."""
    dates: list[str] = []
    opens: list[float] = []
    highs: list[float] = []
    lows: list[float] = []
    closes: list[float] = []
    mnemonic = ''

    with open(path, 'r', encoding='utf-8-sig') as f:
        # Skip header line.
        try:
            next(f)
        except StopIteration:
            return mnemonic, dates, np.array([]), np.array([]), np.array([]), np.array([])
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(',')
            if len(parts) < 8:
                continue
            try:
                if not mnemonic:
                    # Extract mnemonic from ticker field, e.g. "AAPL.US" -> "AAPL"
                    mnemonic = parts[0].split('.')[0]
                # Date: YYYYMMDD -> YYYY-MM-DD
                d = parts[2]
                date_str = f'{d[:4]}-{d[4:6]}-{d[6:8]}'
                o = float(parts[4])
                h = float(parts[5])
                l = float(parts[6])
                c = float(parts[7])
            except (ValueError, IndexError):
                continue
            dates.append(date_str)
            opens.append(o)
            highs.append(h)
            lows.append(l)
            closes.append(c)

    return (
        mnemonic,
        dates,
        np.array(opens, dtype=np.float64),
        np.array(highs, dtype=np.float64),
        np.array(lows, dtype=np.float64),
        np.array(closes, dtype=np.float64),
    )


def find_matches(
    talib_func,
    dates: list[str],
    opens: np.ndarray,
    highs: np.ndarray,
    lows: np.ndarray,
    closes: np.ndarray,
    mnemonic: str,
    max_cases: int,
) -> list[dict]:
    """Run a TA-Lib pattern function and collect windows where it fires."""
    result = talib_func(opens, highs, lows, closes)
    cases: list[dict] = []
    n = len(result)

    for i in range(WINDOW_SIZE - 1, n):
        val = int(result[i])
        if val == 0:
            continue
        start = i - WINDOW_SIZE + 1
        cases.append({
            'open': opens[start:i + 1].tolist(),
            'high': highs[start:i + 1].tolist(),
            'low': lows[start:i + 1].tolist(),
            'close': closes[start:i + 1].tolist(),
            'expected': val,
            'date_from': dates[start],
            'date_to': dates[i],
            'mnemonic': mnemonic,
        })
        if len(cases) >= max_cases:
            break

    return cases


def format_float_list(values: list[float]) -> str:
    """Format a list of floats for Python source, keeping reasonable precision."""
    parts = []
    for v in values:
        s = f'{v:.4f}'
        parts.append(s)
    return '[' + ', '.join(parts) + ']'


def write_test_data_file(pattern_name: str, cases: list[dict], out_dir: Path) -> None:
    """Write a test data Python file for one pattern."""
    filename = f'test_data_{pattern_name}.py'
    path = out_dir / filename

    lines: list[str] = []
    lines.append(f'"""Test data for the {pattern_name} pattern, generated from TA-Lib."""')
    lines.append('')
    lines.append('')
    lines.append(f'# Each entry: (open, high, low, close, expected_result)')
    lines.append(f'# expected_result: +100 bullish, -100 bearish, 0 no match')
    lines.append(f'TEST_DATA_{pattern_name.upper()}: list[tuple[list[float], list[float], list[float], list[float], int]] = [')

    for case in cases:
        comment = f"{case['mnemonic']}@nyse, {case['date_from']} till {case['date_to']}"
        lines.append(f'    # {comment}')
        lines.append(f'    (')
        lines.append(f'        {format_float_list(case["open"])},')
        lines.append(f'        {format_float_list(case["high"])},')
        lines.append(f'        {format_float_list(case["low"])},')
        lines.append(f'        {format_float_list(case["close"])},')
        lines.append(f'        {case["expected"]},')
        lines.append(f'    ),')

    lines.append(']')
    lines.append('')

    path.write_text('\n'.join(lines), encoding='utf-8')


def main() -> None:
    script_dir = Path(__file__).parent
    csv_dir = script_dir
    out_dir = script_dir

    if not csv_dir.exists():
        print(f'ERROR: CSV directory not found: {csv_dir}', file=sys.stderr)
        sys.exit(1)

    # Load all CSV files.
    print(f'Loading CSV files from {csv_dir} ...')
    instruments: list[tuple[str, list[str], np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = []
    for csv_file in sorted(csv_dir.glob('*.txt')):
        mnemonic, dates, opens, highs, lows, closes = parse_csv(csv_file)
        if not mnemonic or len(dates) < WINDOW_SIZE:
            continue
        instruments.append((mnemonic, dates, opens, highs, lows, closes))
    print(f'Loaded {len(instruments)} instruments.')

    # Process each pattern.
    for pattern_name, talib_name in sorted(PATTERN_MAP.items()):
        talib_func = getattr(talib, talib_name, None)
        if talib_func is None:
            print(f'  WARNING: TA-Lib function {talib_name} not found, skipping {pattern_name}')
            continue

        all_cases: list[dict] = []
        has_bullish = False
        has_bearish = False

        for mnemonic, dates, opens, highs, lows, closes in instruments:
            if len(all_cases) >= MAX_CASES_PER_PATTERN:
                break
            remaining = MAX_CASES_PER_PATTERN - len(all_cases)
            cases = find_matches(
                talib_func, dates, opens, highs, lows, closes,
                mnemonic, remaining,
            )
            for c in cases:
                if c['expected'] > 0:
                    has_bullish = True
                else:
                    has_bearish = True
            all_cases.extend(cases)

        if not all_cases:
            print(f'  {pattern_name}: NO MATCHES FOUND across {len(instruments)} instruments')
            write_test_data_file(pattern_name, [], out_dir)
            continue

        direction = 'bullish+bearish' if (has_bullish and has_bearish) else ('bullish' if has_bullish else 'bearish')
        print(f'  {pattern_name}: {len(all_cases)} cases ({direction})')
        write_test_data_file(pattern_name, all_cases, out_dir)

    print('Done.')


if __name__ == '__main__':
    main()
